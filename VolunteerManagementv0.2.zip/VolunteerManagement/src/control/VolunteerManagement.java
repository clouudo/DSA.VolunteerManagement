/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package control;

import boundary.VolunteerManagementUI;
import entity.Volunteer;
import dao.VolunteerDAO;
import utility.messageUI;
import java.util.Map;
import java.util.HashMap;
import java.util.Scanner;

/**
 *
 * @author Yeoh Man Tik
 */
public class VolunteerManagement {

    private Map<Integer, Volunteer> volunteerMap = new HashMap<>();
    private VolunteerManagementUI volunteerUI = new VolunteerManagementUI();
    private VolunteerDAO volunteerDao = new VolunteerDAO();
    private messageUI message = new messageUI();
    Scanner scanner = new Scanner(System.in);

    private int volunteerID = 1;

    public void runVolunteerManagement() {
        int choice = 0;
        do {
            choice = volunteerUI.getMenuChoices();
            switch (choice) {
                case 1:
                    addVolunteer();
                    message.enterMessage();
                    scanner.nextLine();
                    break;
                case 2:
                    displayVolunteer();
                    removeVolunteer();
                    message.enterMessage();
                    scanner.nextLine();
                    break;
                case 4:
                    displayVolunteer();
                    editVolunteer();
                    message.enterMessage();
                    scanner.nextLine();
                    break;
                case 6:
                    displayVolunteer();
                    message.enterMessage();
                    scanner.nextLine();
                    break;
                default:
                    break;
            }
        } while (choice != 0);
    }

    public void editVolunteer() {
        volunteerID = volunteerUI.editVolunteerByID();
        volunteerMap = volunteerDao.retrieveFromFile();
        if (volunteerMap.containsKey(volunteerID)) {
            Volunteer editVolunteer = volunteerMap.get(volunteerID);
            int editChoice = volunteerUI.getEditChoice();
            switch (editChoice) {
                case 1:
                    editVolunteer.setFirstName(volunteerUI.volunteerFirstName());
                    break;
                case 2:
                    editVolunteer.setLastName(volunteerUI.volunteerLastName());
                    break;
                case 3:
                    editVolunteer.setEmail(volunteerUI.volunteerEmail());
                    break;
                case 4:
                    editVolunteer.setPhoneNo(volunteerUI.volunteerPhone());
                    break;
                case 5:
                    break;
                default:
                    break;
            }
            volunteerMap.put(volunteerID, editVolunteer);
            volunteerDao.saveFile(volunteerMap);
        }
    }

    public void removeVolunteer() {
        volunteerID = volunteerUI.removeVolunteerByID();
        volunteerDao.removeContent(volunteerID);
    }

    public int generateNewID() {
        int newID = 1;
        volunteerMap = volunteerDao.retrieveFromFile();
        while (volunteerMap.containsKey(newID)) {
            newID++;
        }
        return newID;
    }

    public void addVolunteer() {
        int numOfVolunteer = volunteerUI.getNumOfVolunteers();
        for (int i = 0; i < numOfVolunteer; i++) {
            Volunteer newVolunteer = volunteerUI.inputVolunteerDetails();
            int newID = generateNewID();
            System.out.println("NewID" + newID);

            volunteerMap.put(newID, newVolunteer);
            volunteerDao.saveFile(volunteerMap);
        }
    }

    public void displayVolunteer() {
        volunteerMap = volunteerDao.retrieveFromFile();
        if (volunteerMap.isEmpty()) {
            System.out.println("No volunteers found.");
        } else {
            for (Map.Entry<Integer, Volunteer> entry : volunteerMap.entrySet()) {
                System.out.println("ID: " + entry.getKey() + ", Volunteer Name: " + entry.getValue().getFirstName() + entry.getValue().getLastName());
            }
        }
    }

    public static void main(String[] args) {
        VolunteerManagement vm = new VolunteerManagement();
        vm.runVolunteerManagement();
    }

}
