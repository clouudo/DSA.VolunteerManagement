/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package boundary;

import entity.Volunteer;
import java.util.Scanner;

/**
 *
 * @author Yeoh Man Tik
 */
public class VolunteerManagementUI {

    Scanner scanner = new Scanner(System.in);

    public int getMenuChoices() {
        System.out.println("\nVOLUNTEER MANAGEMENT SYSTEM");
        System.out.println("1.Add new volunteer");
        System.out.println("2.Remove a volunteer");
        System.out.println("3.Search volunteer");
        System.out.println("4.Edit volunteer's details");
        System.out.println("5.Search events under a volunteer");
        System.out.println("6.List all volunteers");
        System.out.println("7.Generate Summary Report");
        int choice = scanner.nextInt();
        scanner.nextLine();
        System.out.println();
        return choice;
    }
    
    public int getEditChoice(){
        System.out.println("\n1.Edit First Name: ");
        System.out.println("2.Edit Last Name: ");
        System.out.println("3.Edit Email: ");
        System.out.println("4.Edit Phone Number: ");
        System.out.println("5.Edit Events: ");
        int choice = scanner.nextInt();
        scanner.nextLine();
        System.out.println();
        return choice;
    }

    public int getNumOfVolunteers() {
        System.out.println("\nHow many number of volunteers you want to add?: ");
        int num = scanner.nextInt();
        scanner.nextLine();
        return num;
    }

    public void listAllVolunteers(String output) {
        System.out.println("\nList of Volunteers:\n" + output);
    }

    public String volunteerFirstName() {
        System.out.println("Enter Volunteer's First Name: ");
        String name = scanner.nextLine();
        return name;
    }

    public String volunteerLastName() {
        System.out.println("Enter Volunteer's Last Name: ");
        String name = scanner.nextLine();
        return name;
    }

    public String[] volunteerEvent() {
        System.out.println("Enter Number of Events (Enter 0 if None): ");
        int numOfEvents = scanner.nextInt();
        scanner.nextLine();
        if (numOfEvents != 0) {
            String[] events = new String[numOfEvents];
            for (int i = 0; i < numOfEvents; i++) {
                System.out.print("Event " + (i + 1) + ": ");
                events[i] = scanner.nextLine();
            }
            return events;
        }
        else
            return null;
    }

    public String volunteerPhone() {
        System.out.println("Enter Volunteer's Phone Nunber: ");
        String phone = scanner.nextLine();
        return phone;
    }

    public String volunteerEmail() {
        System.out.println("Enter Volunteer's Email: ");
        String email = scanner.nextLine();
        return email;
    }
    
    public int editVolunteerByID(){
        System.out.println("Enter Volunteer's ID to edit: ");
        int volunteerID = scanner.nextInt();
        scanner.nextLine();
        return volunteerID;
    }
    
    public int removeVolunteerByID(){
        System.out.println("Enter Volunteer's ID to remove: ");
        int volunteerID = scanner.nextInt();
        scanner.nextLine();
        return volunteerID;
    }

    public Volunteer inputVolunteerDetails() {
        String volunteerFirstName = volunteerFirstName();
        String volunteerLastName = volunteerLastName();
        String[] events = volunteerEvent();
        String volunteerPhone = volunteerPhone();
        String volunteerEmail = volunteerEmail();

        System.out.println();
        return new Volunteer(volunteerFirstName, volunteerLastName, volunteerEmail, volunteerPhone, events);
    }
}
