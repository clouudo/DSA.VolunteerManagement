/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import entity.Volunteer;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Yeoh Man Tik
 */
public class VolunteerDAO {

    private String fileName = "VolunteerFileV2";

    public void saveFile(Map<Integer, Volunteer> volunteerMap) {
        File file = new File(fileName);
        Map<Integer, Volunteer> existingMap = new HashMap<>();

        //append if file already exists
        if (file.exists()) {
            try {
                ObjectInputStream oiStream = new ObjectInputStream(new FileInputStream(file));
                existingMap = (Map<Integer, Volunteer>) (oiStream.readObject());
                oiStream.close();
            } catch (FileNotFoundException ex) {
                System.out.println("Existing file is not found.");
            } catch (IOException ex) {
                System.out.println("Cannot read from existing file.");
            } catch (ClassNotFoundException ex) {
                System.out.println("Existing file class not found.");
            }
            //Merge existing file with new map
            existingMap.putAll(volunteerMap);
        }

        try (ObjectOutputStream ooStream = new ObjectOutputStream(new FileOutputStream(file))) {
            ooStream.writeObject(existingMap);
            ooStream.close();
        } catch (FileNotFoundException ex) {
            System.out.println("\nFile not found");
        } catch (IOException ex) {
            System.out.println("\nCannot save to file");
        }
    }

    public void removeContent(int volunteerID) {
        File file = new File(fileName);
        Map<Integer, Volunteer> existingMap = new HashMap<>();

        //check if file exists
        if (file.exists()) {
            try {
                ObjectInputStream oiStream = new ObjectInputStream(new FileInputStream(file));
                existingMap = (Map<Integer, Volunteer>) (oiStream.readObject());
                oiStream.close();
            } catch (FileNotFoundException ex) {
                System.out.println("Existing file is not found.");
            } catch (IOException ex) {
                System.out.println("Cannot read from existing file.");
            } catch (ClassNotFoundException ex) {
                System.out.println("Existing file class not found.");
            }
        }

        //match ID with existing ID and saves it
        if (existingMap.containsKey(volunteerID)) {
            existingMap.remove(volunteerID);
            System.out.println("Volunteer ID with " + volunteerID + " has been successfully removed!");

            try (ObjectOutputStream ooStream = new ObjectOutputStream(new FileOutputStream(file))) {
                ooStream.writeObject(existingMap);
                ooStream.close();
            } catch (FileNotFoundException ex) {
                System.out.println("\nFile not found");
            } catch (IOException ex) {
                System.out.println("\nCannot make changes to file");
            }
        }
    }

    public Map<Integer, Volunteer> retrieveFromFile() {
        File file = new File(fileName);
        Map<Integer, Volunteer> volunteerMap = new HashMap<>();
        try {
            ObjectInputStream oiStream = new ObjectInputStream(new FileInputStream(file));
            volunteerMap = (Map<Integer, Volunteer>) (oiStream.readObject());
            oiStream.close();
        } catch (FileNotFoundException ex) {
            System.out.println("\nFile not found");
        } catch (IOException ex) {
            System.out.println("\nCannot read from file");
        } catch (ClassNotFoundException ex) {
            System.out.println("\nClass not found.");
        } finally {
            return volunteerMap;
        }
    }

}
